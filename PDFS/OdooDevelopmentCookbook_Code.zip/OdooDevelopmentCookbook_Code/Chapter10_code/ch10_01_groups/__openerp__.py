# -*- coding: utf-8 -*-
{
    'name': 'Cookbook Ch10 code',
    'depends': ['base'],
    'category': 'Library',
    'data': [
        'views/library_book.xml',
        'security/library_security.xml',
    ],
}
