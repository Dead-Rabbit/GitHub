# -*- coding: utf-8 -*-
{
    'name': 'Chapter 10 code',
    'depends': ['base'],
    'category': u'Library',
    'data': [
        'views/library_book.xml',
    ],
}
