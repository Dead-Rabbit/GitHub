odoo.define('ch14_r01_extending_css_and_javascript_for_the_website', function(require)
{
    var core = require('web.core');
    alert(core._t('Hello world'));
});
