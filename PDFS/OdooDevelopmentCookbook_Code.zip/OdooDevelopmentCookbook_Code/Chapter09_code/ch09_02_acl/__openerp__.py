# -*- coding: utf-8 -*-
{
    'name': 'Chapter 09 code',
    'depends': ['base'],
    'category': u'Library',
    'data': [
        'views/library_book.xml',
        'security/ir.model.access.csv',
    ],
}
