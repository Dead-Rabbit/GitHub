# -*- coding: utf-8 -*-
{
    'name': 'Cookbook Ch09 code',
    'depends': ['base_setup'],
    'category': 'Library',
    'data': [
        'security/ir.model.access.csv',
        'security/library_security.xml',
        'views/library_book.xml',
        'views/res_config_settings.xml',
    ],
}
