{
    'name': 'Chapter 06, Recipe 06 code',
    'summary': 'Call onchange methods on the server side',
    'depends': ['my_module'],
}
