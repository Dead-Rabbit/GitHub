{
    'name': 'Chapter 06, Recipe 07 code',
    'summary': 'Port old API code to the new API',
    'depends': ['base'],
}
