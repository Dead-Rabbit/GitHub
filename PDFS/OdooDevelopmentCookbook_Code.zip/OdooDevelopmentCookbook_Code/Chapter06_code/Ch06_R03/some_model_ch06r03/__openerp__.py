{
    'name': 'Chapter 06, Recipe 03 code',
    'summary': 'Execute raw SQL queries',
    'depends': ['base'],
}
