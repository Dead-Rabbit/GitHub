{
    'name': 'Chapter 06, Recipe 02 code',
    'summary': 'Call a method with a modified context',
    'depends': ['product'],
}
