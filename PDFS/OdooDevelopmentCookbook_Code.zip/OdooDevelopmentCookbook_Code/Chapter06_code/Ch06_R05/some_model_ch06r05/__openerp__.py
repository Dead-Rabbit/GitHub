{
    'name': 'Chapter 06, Recipe 01 code',
    'summary': 'Define onchange methods',
    'depends': ['my_module'],
}
