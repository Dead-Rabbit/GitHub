{
    'name': 'Chapter 06, Recipe 04 code',
    'summary': 'Write a wizard to guide the user',
    'depends': ['my_module'],  # from chapter 3
    'data': ['views.xml'],
}
