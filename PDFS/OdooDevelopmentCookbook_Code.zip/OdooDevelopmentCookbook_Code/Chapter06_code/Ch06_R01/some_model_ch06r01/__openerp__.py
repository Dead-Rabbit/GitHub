{
    'name': 'Chapter 06, Recipe 01 code',
    'summary': 'Change the user performing an action',
    'depends': ['base'],
}
