# -*- coding: utf-8 -*-
{
    'name': 'Chapter 12 code',
    'depends': ['mail'],
    'data': ['views/library_book.xml'],
}
