{
    'name': 'Chapter 07, Recipe 4 code',
    'summary': 'Write tests for your module using YAML',
    'depends': ['my_module'],  # from Chapter 3
    'test': ['test/test_books.yml'],
}
