{
    'name': "Chapter 07 recipe 1",
    'summary': 'Produce server logs to help debug methods',
    'depends': ['product',
                ]
}
