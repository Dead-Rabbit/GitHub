{
    'name': 'Chapter 05, Recipe 1 code',
    'summary': 'Report errors to the user',
    'depends': ['base'], 
}
