{
    'name': 'Chapter 05, Recipe 8 code',
    'summary': 'Filter recordsets',
    'depends': ['base'],
}
