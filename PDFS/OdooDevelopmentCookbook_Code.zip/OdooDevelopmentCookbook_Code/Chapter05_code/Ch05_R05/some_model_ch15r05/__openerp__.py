{
    'name': 'Chapter 05, Recipe 4 code',
    'summary': 'Update values of recordset records',
    'depends': ['my_module'],  # from Chapter 3
}
