{
    'name': 'Chapter 05, Recipe 12 code',
    'summary': 'Customize how records are searched',
    'depends': ['base'],
}
