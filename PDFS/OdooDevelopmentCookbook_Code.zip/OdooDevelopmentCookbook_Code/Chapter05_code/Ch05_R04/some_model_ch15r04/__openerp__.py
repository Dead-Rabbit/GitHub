{
    'name': 'Chapter 05, Recipe 4 code',
    'summary': 'Create new records',
    'depends': ['base'], 
}
