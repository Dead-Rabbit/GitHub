{
    'name': 'Chapter 05, Recipe 1 code',
    'summary': 'Define Model methods and use API decorators',
    'depends': ['my_module'], # from Chapter 3
}
