{
    'name': 'Chapter 05, Recipe 11 code',
    'summary': 'Extend write() and create()',
    'depends': ['my_module'],  # from Chapter 3
}
