{
    'name': 'Chapter 05, Recipe 6 code',
    'summary': 'Search for records',
    'depends': ['base'], 
}
