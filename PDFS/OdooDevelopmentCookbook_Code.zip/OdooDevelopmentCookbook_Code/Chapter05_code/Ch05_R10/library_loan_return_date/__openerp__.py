{
    'name': 'library loan return date',
    'summary': 'Chap 5, recipe 10, '
               'Extend the business logic defined in a Model',
    'depends': ['library_loan_wizard',
                ],
}
