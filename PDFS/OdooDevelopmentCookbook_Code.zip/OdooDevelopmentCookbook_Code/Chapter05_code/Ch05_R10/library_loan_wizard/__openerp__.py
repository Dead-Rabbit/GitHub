{
    'name': 'library loan wizard',
    'summary': 'Chapter 05, Recipe 10 code '
               'Extend the business logic defined in a Model',
    'depends': ['my_module',  # from Chapter 3
                ],
}
