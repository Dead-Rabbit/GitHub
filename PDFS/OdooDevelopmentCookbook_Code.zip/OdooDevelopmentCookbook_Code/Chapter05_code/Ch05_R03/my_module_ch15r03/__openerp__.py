{
    'name': 'Chapter 05, Recipe 1 code',
    'summary': 'Obtain an empty recordset for a different model',
    'depends': ['my_module'], # from Chapter 3
}
