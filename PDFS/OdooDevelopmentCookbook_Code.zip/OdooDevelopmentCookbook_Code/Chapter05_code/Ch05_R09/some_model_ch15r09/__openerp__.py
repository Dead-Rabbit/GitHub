{
    'name': 'Chapter 05, Recipe 9 code',
    'summary': 'Traverse recordset relations',
    'depends': ['base'],
}
