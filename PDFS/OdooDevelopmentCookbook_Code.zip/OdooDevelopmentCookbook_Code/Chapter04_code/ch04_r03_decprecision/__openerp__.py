# -*- coding: utf-8 -*-
{
    'name': 'Chapter 03 code',
    'depends': ['base', 'decimal_precision'],
    'data': ['views/library_book.xml'],
}
