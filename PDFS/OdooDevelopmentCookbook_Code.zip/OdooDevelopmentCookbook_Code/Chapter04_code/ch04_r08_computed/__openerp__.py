# -*- coding: utf-8 -*-
{
    'name': 'Chapter 04 code',
    'depends': ['base'],
    'data': ['views/library_book.xml'],
}
